// Mantra Mehta(mmehta2@toromail.csudh.edu)
public class InsufficientBalanceException extends Exception {

	public InsufficientBalanceException(String message) {
		super(message);
	}

}
