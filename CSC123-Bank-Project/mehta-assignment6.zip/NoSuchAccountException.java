// Mantra Mehta(mmehta2@toromail.csudh.edu)
public class NoSuchAccountException extends Exception {

	public NoSuchAccountException(String message) {
		super(message);
	}

}
