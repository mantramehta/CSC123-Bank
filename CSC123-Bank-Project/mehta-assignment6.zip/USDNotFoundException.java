// Mantra Mehta(mmehta2@toromail.csudh.edu)
public class USDNotFoundException extends Exception {

	public USDNotFoundException(String message) {
		super(message);
	}

}

