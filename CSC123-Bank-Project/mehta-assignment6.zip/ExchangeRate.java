// Mantra Mehta(mmehta2@toromail.csudh.edu)
public class ExchangeRate {
    private String name;
    private double rate;

    public ExchangeRate(String name, double rate) {
        this.name = name;
        this.rate = rate;
    }

    public String getName() {
        return name;
    }

    public double getRate() {
        return rate;
    }
}
