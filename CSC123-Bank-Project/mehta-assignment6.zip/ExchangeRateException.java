// Mantra Mehta(mmehta2@toromail.csudh.edu)
public class ExchangeRateException extends Exception {

	public ExchangeRateException(String message) {
		super(message);
	}

}
